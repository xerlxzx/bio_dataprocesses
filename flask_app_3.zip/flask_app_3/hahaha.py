import decimal
b = float(input("Enter the beta(coefficient for US): "))
L = float(input("Enter the total learning(lambda): "))
n = int(input("Enter trials of learning: "))

Num_CS = int(input("Enter the number of CS: "))

alphas = []
vs = []

sum_of_v = 0
for i in range(Num_CS):
  a = float(input(f"Enter the alpha for CS{i+1}: "))
  v = float(input(f"Enter initial learning(V) for CS{i+1}: "))
  sum_of_v += v  #initial learning
  alphas.append(a)
  vs.append(v)

change_of_v = 0

for k in range(n):
  change_of_v = [alpha * b * (L - sum_of_v) for alpha in alphas]
  sum_of_v += sum(change_of_v)
  vs = [x + y for x, y in zip(change_of_v, vs)]
  print(f"after trial {k+1}, the change of learning in this trial for each CS are: ", [round(num, 4) for num in change_of_v])
  print(f'the total learning for each CS are' , [round(num,4) for num in vs])
  print(f"and the total learning in this trials is", round(sum_of_v, 4))
