from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.json
    b = float(data['beta'])
    L = float(data['lambda'])
    n = int(data['trials'])
    Num_CS = int(data['num_cs'])

    alphas = data['alphas']
    vs = data['vs']

    sum_of_v = sum(vs)
    results = []

    for k in range(n):
        change_of_v = [alpha * b * (L - sum_of_v) for alpha in alphas]
        sum_of_v += sum(change_of_v)
        vs = [x + y for x, y in zip(change_of_v, vs)]
        trial_result = {
            'trial': k + 1,
            'change_of_v': [round(num, 4) for num in change_of_v],
            'total_learning_cs': [round(num, 4) for num in vs],
            'total_learning': round(sum_of_v, 4)
        }
        results.append(trial_result)

    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
